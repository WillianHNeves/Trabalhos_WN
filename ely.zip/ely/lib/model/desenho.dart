class Desenho {
  int _id;
  String _nome;
  String _lancamento;
  String _categoria;
  String _producao;

  Desenho(
      this._nome, this._lancamento, this._categoria, this._producao);

  Desenho.map(dynamic obj) {
    this._id = obj['id'];
    this._nome = obj['nome'];
    this._lancamento = obj['lancamento'];
    this._categoria = obj['categoria'];
    this._producao = obj['producao'];
  }

  int get id => _id;
  String get nome => _nome;
  String get lancamento => _lancamento;
  String get categoria => _categoria;
  String get producao => _producao;

  Map<String, dynamic> toMap() {
    var map = new Map<String, dynamic>();
    if (_id != null) {
      map['id'] = _id;
    }
    map['nome'] = _nome;
    map['lancamento'] = _lancamento;
    map['categoria'] = _categoria;
    map['producao'] = _producao;
    return map;
  }

  Desenho.fromMap(Map<String, dynamic> map) {
    this._id = map['id'];
    this._nome = map['nome'];
    this._lancamento = map['lancamento'];
    this._categoria = map['categoria'];
    this._producao = map['producao'];
  }
}
