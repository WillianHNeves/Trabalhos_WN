import 'package:flutter/material.dart';
import '../model/desenho.dart';
import '../db/database_helper.dart';
import 'desenho_screen.dart';

class ListViewDesenho extends StatefulWidget {
  @override
  _ListViewDesenhoState createState() => new _ListViewDesenhoState();
}


class _ListViewDesenhoState extends State<ListViewDesenho> {
  List<Desenho> items = new List();
  DatabaseHelper db = new DatabaseHelper();
  @override
  void initState() {
    super.initState();
    db.getDesenho().then((desenhos) {
      setState(() {
        desenhos.forEach((desenho) {
          items.add(Desenho.fromMap(desenho));
        });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cadastro',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Desenhos Animados'),
          centerTitle: true,
          backgroundColor: Colors.blue,
        ),
        body: Center(
          child: ListView.builder(
              itemCount: items.length,
              padding: const EdgeInsets.all(15.0),
              itemBuilder: (context, position) {
                return Column(
                  children: [
                    Divider(height: 5.0),
                    ListTile(
                      title: Text(
                        '${items[position].nome}',
                        style: TextStyle(
                          fontSize: 22.0,
                          color: Colors.deepOrangeAccent,
                        ),
                      ),
                      subtitle: Row(children: [
                        Text('Ano de lançamento: ${items[position].lancamento} - Categoria: ${items[position].categoria} - Estúdio de produção: ${items[position].producao}',
                            style: new TextStyle(
                              fontSize: 18.0,
                              fontStyle: FontStyle.italic,
                            )),
                      
                        IconButton(
                            icon: const Icon(Icons.remove_circle_outline),
                            onPressed: () => _deleteDesenho(
                                context, items[position], position)),
                      ]),
                      leading: CircleAvatar(
                        backgroundColor: Colors.purple,
                        radius: 15.0,
                        child: Text(
                          '${items[position].id}',
                          style: TextStyle(
                            fontSize: 15.0,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      onTap: () => _navigateToDesenho(context, items[position]),
                    ),
                  ],
                );
              }),
        ),
        floatingActionButton: FloatingActionButton(
          child: Icon(Icons.add),
          onPressed: () => _createNewDesenho(context),
          backgroundColor: Colors.blue,
        ),
      ),
    );
  }

  void _deleteDesenho(BuildContext context, Desenho desenho, int position) async {
    db.deleteDesenho(desenho.id).then((desenhos) {
      setState(() {
        items.removeAt(position);
      });
    });
  }

  void _navigateToDesenho(BuildContext context, Desenho desenho) async {
    String result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => DesenhoScreen(desenho)),
    );
    if (result == 'update') {
      db.getDesenho().then((desenhos) {
        setState(() {
          items.clear();
          desenhos.forEach((desenho) {
            items.add(Desenho.fromMap(desenho));
          });
        });
      });
    }
  }

  void _createNewDesenho(BuildContext context) async {
    String result = await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => DesenhoScreen(Desenho('', '', '', ''))),
    );
    if (result == 'save') {
      db.getDesenho().then((desenhos) {
        setState(() {
          items.clear();
          desenhos.forEach((desenho) {
            items.add(Desenho.fromMap(desenho));
          });
        });
      });
    }
  }
}
