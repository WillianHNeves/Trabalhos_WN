import 'package:flutter/material.dart';
import '../model/desenho.dart';
import '../db/database_helper.dart';

class DesenhoScreen extends StatefulWidget {
  final Desenho desenho;
  DesenhoScreen(this.desenho);
  @override
  State<StatefulWidget> createState() => new _DesenhoScreenState();
}

class _DesenhoScreenState extends State<DesenhoScreen> {
  DatabaseHelper db = new DatabaseHelper();
  TextEditingController _nomeController;
  TextEditingController _lancamentoController;
  TextEditingController _categoriaController;
  TextEditingController _producaoController;

  @override
  void initState() {
    super.initState();
    _nomeController = new TextEditingController(text: widget.desenho.nome);
    _lancamentoController = new TextEditingController(text: widget.desenho.lancamento);
    _categoriaController =
        new TextEditingController(text: widget.desenho.categoria);
    _producaoController = new TextEditingController(text: widget.desenho.producao);
  }
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Desenho')),
      body: Container(
        margin: EdgeInsets.all(15.0),
        alignment: Alignment.center,
        child: Column(
          children: [
            Image.network(
            'https://static.quizur.com/i/b/57c9e953e0c6e3.8283355357c9e953c806c6.90631050.jpg',
             width: 500,
             height: 300,
             alignment: Alignment.center,
            ),
            TextField(
              controller: _nomeController,
              decoration: InputDecoration(labelText: 'Nome'),
            ),
            Padding(padding: new EdgeInsets.all(5.0)),
            TextField(
              controller: _lancamentoController,
              decoration: InputDecoration(labelText: 'Ano de lançamento'),
            ),
            Padding(padding: new EdgeInsets.all(5.0)),
            TextField(
              controller: _categoriaController,
              decoration: InputDecoration(labelText: 'Categoria'),
            ),
            Padding(padding: new EdgeInsets.all(5.0)),
            TextField(
              controller: _producaoController,
              decoration: InputDecoration(labelText: 'Estúdio de produção'),
            ),
            Padding(padding: new EdgeInsets.all(5.0)),
            RaisedButton(
              child: (widget.desenho.id != null)
                  ? Text('Alterar')
                  : Text('Inserir'),
              onPressed: () {
                if (widget.desenho.id != null) {
                  db.updateDesenho(Desenho.fromMap({
                    'id': widget.desenho.id,
                    'nome': _nomeController.text,
                    'lancamento': _lancamentoController.text,
                    'categoria': _categoriaController.text,
                    'producao': _producaoController.text
                  }))
                      .then((_) {
                    Navigator.pop(context, 'update');
                  });
                } else {
                  db
                      .inserirDesenho(Desenho(
                          _nomeController.text,
                          _lancamentoController.text,
                          _categoriaController.text,
                          _producaoController.text))
                      .then((_) {
                    Navigator.pop(context, 'save');
                  });
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}