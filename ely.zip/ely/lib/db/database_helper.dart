import 'dart:async';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../model/desenho.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = new DatabaseHelper.internal();
  factory DatabaseHelper() => _instance;
  static Database _db;
  DatabaseHelper.internal();
  Future<Database> get db async {
    if (_db != null) {
      return _db;
    }
    _db = await initDb();
    return _db;
  }

  initDb() async {
    String databasesPath = await getDatabasesPath();
    String path = join(databasesPath, 'notes.db');
    var db = await openDatabase(path, version: 1, onCreate: _onCreate);
    return db;
  }

  void _onCreate(Database db, int newVersion) async {
    await db.execute(
        'CREATE TABLE desenho(id INTEGER PRIMARY KEY, nome TEXT, lancamento TEXT, categoria TEXT, producao TEXT)');
  }

  Future<int> inserirDesenho(Desenho desenho) async {
    var dbClient = await db;
    var result = await dbClient.insert("desenho", desenho.toMap());
    return result;
  }

  Future<List> getDesenho() async {
    var dbClient = await db;
    var result = await dbClient.query("desenho",
        columns: ["id", "nome", "lancamento", "categoria", "producao"]);
    return result.toList();
  }

  Future<int> getCount() async {
    var dbClient = await db;
    return Sqflite.firstIntValue(
        await dbClient.rawQuery('SELECT COUNT(*) FROM desenho'));
  }

  Future<Desenho> getDesenhos(int id) async {
    var dbClient = await db;
    List<Map> result = await dbClient.query("desenho",
        columns: ["id", "nome", "lancamento", "categoria", "producao"],
        where: 'ide = ?',
        whereArgs: [id]);
    if (result.length > 0) {
      return new Desenho.fromMap(result.first);
    }
    return null;
  }

  Future<int> deleteDesenho(int id) async {
    var dbClient = await db;
    return await dbClient.delete("desenho", where: 'id = ?', whereArgs: [id]);
  }

  Future<int> updateDesenho(Desenho desenho) async {
    var dbClient = await db;
    return await dbClient.update("desenho", desenho.toMap(),
        where: "id = ?", whereArgs: [desenho.id]);
  }

  Future close() async {
    var dbClient = await db;
    return dbClient.close();
  }
}
